#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
#set($NAME_LOWER_CASE = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($NAME_SINGULAR = ${StringUtils.chop($NAME, 1)})
#set($NAME_DTO = ${StringUtils.chop($NAME, 1)} + "Dto")
#set($NAME_DTO_VAR = $NAME_DTO.substring(0,1).toLowerCase() + $NAME_DTO.substring(1))
/**
 * @author Sergey Stol
 * ${YEAR}-${MONTH}-${DAY}
 */
@RestController
@RequestMapping("/v1" + "/${NAME_LOWER_CASE}")
@RequiredArgsConstructor
public class ${NAME}Controller {
    private final ${NAME}Service service;

    // GET /v1/${NAME_LOWER_CASE}/:id
    @GetMapping(value = "/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ${NAME_DTO} get${NAME_SINGULAR}ById(@PathVariable long id) {
        return service.get${NAME_SINGULAR}(id);
    }

    // GET /v1/${NAME_LOWER_CASE}
    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<${NAME_DTO}> get${NAME}() {
        return service.get${NAME}();
    }

    // POST /v1/${NAME_LOWER_CASE}
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public String add${NAME_SINGULAR}(@RequestBody ${NAME_DTO} ${NAME_DTO_VAR}) {
        return service.add${NAME_SINGULAR}(${NAME_DTO_VAR});
    }

    // PUT /v1/${NAME_LOWER_CASE}
    @PutMapping
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void update${NAME_SINGULAR}(${NAME_DTO} ${NAME_DTO_VAR}) {
        service.update${NAME_SINGULAR}(${NAME_DTO_VAR});
    }

    // DELETE /v1/${NAME_LOWER_CASE}/:id
    @DeleteMapping(value = "/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete${NAME_SINGULAR}(@PathVariable long id) {
        service.delete${NAME_SINGULAR}(id);
    }
}