#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
#set($NAME_DAO = ${StringUtils.chop($NAME, 1)} + "Dao")
/**
 * @author Sergey Stol
 * ${YEAR}-${MONTH}-${DAY}
 */
@Repository
public interface ${NAME}Repository} extends MongoRepository<${NAME_DAO}, Long> {
}
