#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Sergey Stol
 * ${YEAR}-${MONTH}-${DAY}
*/
@org.springframework.boot.autoconfigure.SpringBootApplication
public class ${NAME} {
    public static void main(String ...args) {
        org.springframework.boot.SpringApplication.run(${NAME}.class, args);
    }
}