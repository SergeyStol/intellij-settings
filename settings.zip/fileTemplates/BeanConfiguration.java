#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
#set($NAME_LOWER_CASE = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
/**
 * @author Sergey Stol
 * ${YEAR}-${MONTH}-${DAY}
 */
@Configuration
public class ${NAME}Configuration {
    @Bean
    ${NAME} ${NAME_LOWER_CASE}() {
        return new ${NAME}();
    }
}