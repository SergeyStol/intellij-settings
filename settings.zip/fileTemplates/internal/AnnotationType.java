#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import java.lang.annotation.Retention;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author Sergey Stol
 * ${YEAR}-${MONTH}-${DAY}
*/
@Retention(RUNTIME)
public @interface ${NAME} {
}
