#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
#set($NAME_LOWER_CASE = $NAME.substring(0,1).toLowerCase() + $NAME.substring(1))
#set($NAME_SINGULAR = ${StringUtils.chop($NAME, 1)})
#set($NAME_SINGULAR_UPPER_CASE = $NAME_SINGULAR.toUpperCase())
#set($NAME_DTO = ${StringUtils.chop($NAME, 1)} + "Dto")
#set($NAME_DTO_VAR = $NAME_DTO.substring(0,1).toLowerCase() + $NAME_DTO.substring(1))
#set($NAME_DAO = ${StringUtils.chop($NAME, 1)} + "Dao")
#set($NAME_DAO_VAR = $NAME_DAO.substring(0,1).toLowerCase() + $NAME_DAO.substring(1))
/**
 * @author Sergey Stol
 * ${YEAR}-${MONTH}-${DAY}
*/
@Service
@RequiredArgsConstructor
public class ${NAME}Service {
    private final ${NAME}Repository repo;
    private final ModelMapper modelMapper;

    public ${NAME_DTO} get${NAME_SINGULAR}(long id) {
        return repo.findById(id)
                .map(this::convertTo${NAME_DTO})
                .orElseThrow(() -> new NotFoundException(CANT_FIND_${NAME_SINGULAR_UPPER_CASE}_WITH_ID));
    }

    public List<${NAME_DTO}> get${NAME}() {
        return repo.findAll().stream()
                .map(this::convertTo${NAME_DTO})
                .collect(Collectors.toList());
    }

    public void add$NAME_SINGULAR(${NAME_DTO} ${NAME_DTO_VAR}) {
        repo.save(convertTo${NAME_DAO}(${NAME_DTO_VAR}));
    }

    public void update${NAME_SINGULAR}(${NAME_DTO} ${NAME_DTO_VAR}) {
        repo.save(convertTo${NAME_DAO}(${NAME_DTO_VAR}));
    }

    public void delete${NAME_SINGULAR}(long id) {
        repo.deleteById(id);
    }

    public ${NAME_DTO} convertTo${NAME_DTO}(${NAME_DAO} ${NAME_DAO_VAR}) {
        return modelMapper.map(${NAME_DAO_VAR}, ${NAME_DTO}.class);
    }

    public ${NAME_DAO} convertTo${NAME_DAO}(${NAME_DTO} ${NAME_DTO_VAR}) {
        return modelMapper.map(${NAME_DTO_VAR}, ${NAME_DAO}.class);
    }
}