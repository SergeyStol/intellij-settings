#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author Sergey Stol
 * ${YEAR}-${MONTH}-${DAY}
*/
@Service
public class ${NAME} {
    @PostConstruct
    void init() {
        #[[$END$]]#
    }
}